void CountUpandDown(int maxCount);
void ScrollName(char *name);
